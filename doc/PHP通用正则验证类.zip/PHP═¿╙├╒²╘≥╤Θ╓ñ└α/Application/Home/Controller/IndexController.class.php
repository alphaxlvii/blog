<?php

namespace Home\Controller;

use Think\Controller;

class IndexController extends Controller {

    public function index() {
        $this->display();
    }
    public function check() {
        import('Org.Util.Verify');
        $verify = new \Verify();
        $mobile = I("post.mobile");
        
        $rs = $verify->isMobile($mobile); //判断是否是手机号
        if($rs == true){
            echo 1;
        }else{
            echo -1;
        }
    }

}
